const C="mfs-v5",F=["index.html","manifest.webmanifest","icon-192.png","icon-512.png","danielbd.ttf"];
self.addEventListener("install",e=>e.waitUntil(caches.open(C).then(c=>Promise.all(F.map(f=>c.add(f).catch(()=>0))))));
self.addEventListener("fetch",e=>e.respondWith(fetch(e.request).catch(()=>caches.match(e.request))));
