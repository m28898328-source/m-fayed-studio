# M-Fayed Studio — مشروع تطبيق الأندرويد (APK)

## الطريقة الأسهل (من غير ما تنزل أي برنامج)
1. حط ملف الخط `danielbd.ttf` جوه مجلد `www` جنب `index.html`.
2. اعمل حساب مجاني على github.com وأنشئ Repository جديد، وارفع محتويات المجلد ده كله (بما فيهم `.github`).
3. من تبويب **Actions** اختار **Build APK** ثم **Run workflow**.
4. بعد ~5 دقايق نزّل `m-fayed-studio-apk` من الـ Artifacts، وجواه `app-debug.apk` ثبّته على موبايلك (فعّل «التثبيت من مصادر غير معروفة»).

## الطريقة اليدوية (على الكمبيوتر)
محتاج Node 20 و JDK 17 و Android SDK:
```
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
الملف الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`

## بديل: تحويل سريع
ارفع مجلد `www` على أي استضافة HTTPS مجانية، وادخل على pwabuilder.com وحوّله لـ APK.

## ملاحظات
- التطبيق بيشتغل أوفلاين، لكن تحميل سور القرآن لأول مرة وخطوط Google محتاجين إنترنت.
- لإصدار نسخة للنشر على Google Play لازم توقيع (keystore) — الـ APK ده Debug للتجربة والتوزيع المباشر.
